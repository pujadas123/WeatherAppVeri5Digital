package com.example.weatherapp.service.weatherservice;

public enum ParseResult {OK, JSON_EXCEPTION, CITY_NOT_FOUND}
