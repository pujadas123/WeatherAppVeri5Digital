package com.example.weatherapp.utils;

public class Constants {

    //App Constants
    public static final String PREFERENCE_NAME = "weather_preference_v_0_1";

    public static final String DEFAULT_CITY_ID = "2643743";

    public static final String BASE_URL = "http://api.openweathermap.org/data/2.5/";
    public static final String API_KEY = "cc5db9cf47e272b14285b52bf0e71505";
    public static final String UNITS = "metric";
    public static String TEMP_UNIT = "";
}
